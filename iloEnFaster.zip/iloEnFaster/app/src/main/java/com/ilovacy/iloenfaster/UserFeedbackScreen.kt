package com.ilovacy.iloenfaster

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun UserFeedbackScreen(navController: NavController) {
    var feedbackText by remember { mutableStateOf("") }
    var showDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(text = "用户反馈", fontSize = 20.sp, color = Color.Black, modifier = Modifier.padding(bottom = 8.dp))

        OutlinedTextField(
            value = feedbackText,
            onValueChange = { feedbackText = it },
            label = { Text("请输入您的反馈") },
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .padding(vertical = 8.dp)
        )

        Button(
            onClick = {
                showDialog = true
            },
            modifier = Modifier.align(Alignment.End)
        ) {
            Text("提交")
        }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("提示") },
            text = { Text("我们已收到提供的宝贵建议") },
            confirmButton = {
                Button(
                    onClick = {
                        showDialog = false
                        feedbackText = ""
                    }
                ) {
                    Text("确定")
                }
            }
        )
    }
}
