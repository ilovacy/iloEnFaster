package com.ilovacy.iloenfaster

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val sharedPreferences = application.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE)

    private val _isDarkTheme = MutableLiveData(sharedPreferences.getBoolean("isDarkTheme", false))
    val isDarkTheme: LiveData<Boolean> = _isDarkTheme

    private val _fontSize = MutableLiveData(sharedPreferences.getFloat("fontSize", 16f))
    val fontSize: LiveData<Float> = _fontSize

    fun toggleTheme() {
        val newTheme = !_isDarkTheme.value!!
        _isDarkTheme.value = newTheme
        sharedPreferences.edit().putBoolean("isDarkTheme", newTheme).apply()
    }

    fun updateFontSize(newSize: Float) {
        _fontSize.value = newSize
        sharedPreferences.edit().putFloat("fontSize", newSize).apply()
    }
}
