package com.ilovacy.iloenfaster

//data class Word(
//    val wordRank: Int,
//    val headWord: String,
//    val content: WordContent
//)

data class WordContent(
    val wordHead: String,
    val usphone: String,
    val trans: List<Translation>,
    val sentence: SentenceContent,
    val exam: List<Exam>,
    val syno: Synonym,
    val phrase: Phrase,
    val relWord: RelatedWord
)

data class Translation(
    val tranCn: String,
    val pos: String,
    val tranOther: String
)

data class SentenceContent(
    val sentences: List<Sentence>,
    val desc: String
)

data class Sentence(
    val sContent: String,
    val sCn: String
)

data class Exam(
    val question: String,
    val answer: Answer,
    val examType: Int,
    val choices: List<Choice>
)

data class Answer(
    val explain: String,
    val rightIndex: Int
)

data class Choice(
    val choiceIndex: Int,
    val choice: String
)

data class Synonym(
    val synos: List<Syno>,
    val desc: String
)

data class Syno(
    val pos: String,
    val tran: String,
    val hwds: List<Hwd>
)

data class Hwd(
    val w: String
)

data class Phrase(
    val phrases: List<Phr>,
    val desc: String
)

data class Phr(
    val pContent: String,
    val pCn: String
)

data class RelatedWord(
    val rels: List<Rel>,
    val desc: String
)

data class Rel(
    val pos: String,
    val words: List<RelWord>
)

data class RelWord(
    val hwd: String,
    val tran: String
)
