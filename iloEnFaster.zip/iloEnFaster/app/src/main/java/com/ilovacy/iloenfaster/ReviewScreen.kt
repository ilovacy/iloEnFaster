package com.ilovacy.iloenfaster

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.SoftwareKeyboardController
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.File
import java.io.FileReader
import java.io.FileWriter

data class Word(val 序号: String, val 单词: String, val 注音: String, val 释义: String)

@Composable
fun ReviewScreen(context: Context) {
    var displayMode_review by remember { mutableStateOf(DisplayMode.WORD_PRONUNCIATION) }
    val wordsPerPage_review = 10
    var words by remember { mutableStateOf(emptyList<Word>()) }
    var searchText_review by remember { mutableStateOf(TextFieldValue("")) }
    var filteredWords_review by remember { mutableStateOf(words) }

    LaunchedEffect(Unit) {
        words = loadWords(context)
        filteredWords_review = words
    }

    val paginatedWords_review = filteredWords_review.chunked(wordsPerPage_review)
    var currentWordIndex_review by remember { mutableStateOf(0) }
    var initialPage_review by remember { mutableStateOf(0) }
    var currentPage_review by remember { mutableStateOf(0) }
    val listState_review = rememberLazyListState()
    val keyboardController_review = LocalSoftwareKeyboardController.current

    LaunchedEffect(Unit) {
        currentWordIndex_review = getCurrentWordIndex_review(context, "review_index.json")
        initialPage_review = currentWordIndex_review / wordsPerPage_review
        currentPage_review = initialPage_review
    }

    LaunchedEffect(searchText_review.text) {
        filteredWords_review = if (searchText_review.text.isEmpty()) {
            words
        } else {
            words.filter {
                it.单词.startsWith(searchText_review.text, ignoreCase = true) ||
                        it.释义.contains(searchText_review.text, ignoreCase = true)
            }.sortedBy { it.单词.startsWith(searchText_review.text, ignoreCase = true).not() }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SearchField_review(
                value = searchText_review,
                onValueChange = { searchText_review = it },
                onSearch = {
                    filteredWords_review = words.filter {
                        it.单词.startsWith(searchText_review.text, ignoreCase = true) ||
                                it.释义.contains(searchText_review.text, ignoreCase = true)
                    }.sortedBy { it.单词.startsWith(searchText_review.text, ignoreCase = true).not() }
                },
                keyboardController = keyboardController_review,
                modifier = Modifier.weight(1f)
            )
        }

        LazyColumn(state = listState_review, modifier = Modifier.weight(1f)) {
            itemsIndexed(paginatedWords_review.getOrElse(currentPage_review) { emptyList() }) { index, word ->
                WordItem_review(word = word, displayMode_review = displayMode_review, context = context)
                if (index == 0) {
                    LaunchedEffect(key1 = word) {
                        saveCurrentWordIndex_review(context, currentPage_review * wordsPerPage_review + index, "review_index.json")
                    }
                }
            }
        }

        ControlButtons_review(
            displayMode_review,
            currentPage_review,
            paginatedWords_review.size,
            onStateChange = { newDisplayMode_review, newCurrentPage_review ->
                displayMode_review = newDisplayMode_review
                currentPage_review = newCurrentPage_review
                runBlocking {
                    listState_review.scrollToItem(0)
                }
            }
        )
    }
}

@Composable
fun SearchField_review(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    onSearch: () -> Unit,
    keyboardController: SoftwareKeyboardController?,
    modifier: Modifier = Modifier
) {
    TextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text("搜索") },
        trailingIcon = {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "搜索",
                tint = Color(0xFF8A8EFF),
                modifier = Modifier.clickable { onSearch() }
            )
        },
        keyboardOptions = KeyboardOptions.Default.copy(
            imeAction = ImeAction.Search
        ),
        keyboardActions = KeyboardActions(
            onSearch = {
                keyboardController?.hide()
                onSearch()
            }
        ),
        colors = TextFieldDefaults.textFieldColors(
            backgroundColor = Color.Transparent,
            cursorColor = Color.DarkGray,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent
        ),
        modifier = modifier
            .border(
                BorderStroke(2.dp, Color(0xFF8A8EFF)),
                shape = RoundedCornerShape(8.dp)
            )
            .background(Color.White, RoundedCornerShape(8.dp))
    )
}

@Composable
fun ControlButtons_review(
    displayMode_review: DisplayMode,
    currentPage_review: Int,
    totalPages_review: Int,
    onStateChange: (DisplayMode, Int) -> Unit
) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        Button(
            onClick = { if (currentPage_review > 0) onStateChange(displayMode_review, currentPage_review - 1) },
            colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF8A8EFF))
        ) {
            Text("上一页", color = Color.White)
        }
        Button(
            onClick = {
                val newDisplayMode_review = when (displayMode_review) {
                    DisplayMode.WORD -> DisplayMode.WORD_PRONUNCIATION
                    DisplayMode.WORD_PRONUNCIATION -> DisplayMode.DEFINITION
                    DisplayMode.DEFINITION -> DisplayMode.WORD
                }
                onStateChange(newDisplayMode_review, currentPage_review)
            },
            colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF8A8EFF))
        ) {
            Text("切换显示", color = Color.White)
        }
        Button(
            onClick = { if (currentPage_review < totalPages_review - 1) onStateChange(displayMode_review, currentPage_review + 1) },
            colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF8A8EFF))
        ) {
            Text("下一页", color = Color.White)
        }
    }
}

@Composable
fun WordItem_review(word: Word, displayMode_review: DisplayMode, context: Context) {
    val textToShow = when (displayMode_review) {
        DisplayMode.WORD -> word.单词
        DisplayMode.WORD_PRONUNCIATION -> "${word.单词}\n[${word.注音}]\n[${word.释义}]"
        DisplayMode.DEFINITION -> word.释义
    }

    val coroutineScope_review = rememberCoroutineScope()

    Surface(
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        elevation = 10.dp
    ) {
        Box(
            modifier = Modifier
                .clickable(
                    onClick = { coroutineScope_review.launch { downloadAndPlayAudio(context, word.单词) } },
                    indication = rememberRipple(bounded = true),
                    interactionSource = remember { MutableInteractionSource() }
                )
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.White, Color.White)
                    ),
                    shape = RoundedCornerShape(10.dp)
                )
                .padding(16.dp)
                .heightIn(min = 64.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.Start,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = textToShow,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    fontFamily = FontFamily(Font(R.font.consolas)),
                    color = Color.Gray
                )
            }
        }
    }
}

//fun loadWords(context: Context): List<Word> {
//    val gson = Gson()
//    val file = File(context.filesDir, "words.json")
//    val type = object : TypeToken<List<Word>>() {}.type
//    return if (file.exists()) {
//        FileReader(file).use { gson.fromJson(it, type) }
//    } else {
//        emptyList()
//    }
//}

fun getCurrentWordIndex_review(context: Context, fileName: String): Int {
    val file = File(context.filesDir, fileName)
    return if (file.exists()) {
        file.readText().toInt()
    } else {
        0
    }
}

fun saveCurrentWordIndex_review(context: Context, index: Int, fileName: String) {
    val file = File(context.filesDir, fileName)
    FileWriter(file).use { it.write(index.toString()) }
}

//fun downloadAndPlayAudio(context: Context, word: String) {
//    // Implement audio download and play logic here
//}

enum class DisplayMode {
    WORD, WORD_PRONUNCIATION, DEFINITION
}
