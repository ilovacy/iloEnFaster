package com.ilovacy.iloenfaster

data class WordCountData(
    var todayDate: String,
    var todayWords: Int,
    var totalWords: Int
)
