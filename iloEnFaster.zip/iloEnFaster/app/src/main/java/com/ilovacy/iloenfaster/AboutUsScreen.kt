package com.ilovacy.iloenfaster

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun AboutUsScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "关于我们",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center,
                        color = Color.White
                    )
                },
                backgroundColor = Color(0xFF8A8EFF),
                contentColor = Color.White
            )
        },
        content = { innerPadding ->
            Box(modifier = Modifier.padding(innerPadding)) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "团队介绍",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        textAlign = TextAlign.Center
                    )
                    TeamInfo(
                        title = "开发团队",
                        content = "    \t希望之翼"
                    )
                    Divider(modifier = Modifier.padding(vertical = 4.dp))
                    TeamInfo(
                        title = "开发者",
                        content = "    \tilovacy (徐慧博)"
                    )
                    Divider(modifier = Modifier.padding(vertical = 4.dp))
                    TeamInfo(
                        title = "产品经理",
                        content = "    \t吴文达"
                    )
                    Divider(modifier = Modifier.padding(vertical = 4.dp))
                    TeamInfo(
                        title = "功能测试",
                        content = "    \t郭建翔, 刘潇瑜"
                    )
                }
            }
        }
    )
}

@Composable
fun TeamInfo(title: String, content: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = "$title: ",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = content,
            fontSize = 16.sp,
            color = Color.Gray,
            modifier = Modifier.weight(2f)
        )
    }
}
