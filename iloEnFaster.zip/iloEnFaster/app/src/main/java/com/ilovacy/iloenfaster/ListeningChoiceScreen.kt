package com.ilovacy.iloenfaster

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ListeningChoiceScreen(navController: NavController) {
    val context = LocalContext.current
    val words = remember { loadWords(context) }
    var currentWord by remember { mutableStateOf<Word?>(null) }
    var choices by remember { mutableStateOf(listOf<String>()) }
    var selectedChoice by remember { mutableStateOf<String?>(null) }
    var wordIndex by remember { mutableStateOf(getListeningChoiceWordIndex(context)) }
    val coroutineScope = rememberCoroutineScope()
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    fun generateChoices(currentWord: Word?, words: List<Word>) {
        currentWord?.let {
            val correctAnswer = it.释义
            val wrongAnswers = words.shuffled().filter { it != currentWord }.take(3).map { it.释义 }
            choices = (wrongAnswers + correctAnswer).shuffled()
        }
    }

    fun prepareMediaPlayer(word: String) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(context, Uri.parse("https://dict.youdao.com/dictvoice?type=2&audio=$word"))
            setOnPreparedListener { start() }
            prepareAsync()
        }
    }

    LaunchedEffect(words) {
        if (words.isNotEmpty()) {
            currentWord = words[wordIndex]
            generateChoices(currentWord, words)
            currentWord?.let { word ->
                prepareMediaPlayer(word.单词)
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.release()
        }
    }

    Scaffold(
        topBar = { ListeningChoiceTopBar() },
        content = { innerPadding ->
            Box(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .background(Color(0xFFF5F5F5))
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Spacer(modifier = Modifier.height(32.dp))
                    currentWord?.let { word ->
                        IconButton(
                            onClick = {
                                mediaPlayer?.release()
                                mediaPlayer = MediaPlayer().apply {
                                    setDataSource(context, Uri.parse("https://dict.youdao.com/dictvoice?type=2&audio=${word.单词}"))
                                    setOnPreparedListener { start() }
                                    prepareAsync()
                                }
                            }
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_speaker),
                                contentDescription = "Play Audio",
                                tint = Color.Black,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        choices.forEach { choice ->
                            ChoiceButton2(
                                text = choice,
                                onClick = {
                                    selectedChoice = choice
                                    val isCorrect = choice == word.释义
                                    if (isCorrect) {
                                        coroutineScope.launch {
                                            delay(300)
                                            selectedChoice = null
                                            wordIndex = (wordIndex + 1) % words.size
                                            currentWord = words[wordIndex]
                                            saveListeningChoiceWordIndex(context, wordIndex)
                                            generateChoices(currentWord, words)
                                            prepareMediaPlayer(currentWord?.单词 ?: "")
                                        }
                                    }
                                },
                                isCorrect = selectedChoice == choice && choice == word.释义,
                                isSelected = selectedChoice == choice,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 1.dp, vertical = 5.dp)
                                    .heightIn(min = 100.dp)
                            )
                        }
                    } ?: run {
                        Text("加载单词中...", fontSize = 18.sp, color = Color.Gray)
                    }
                }
            }
        }
    )
}

@Composable
fun ListeningChoiceTopBar() {
    TopAppBar(
        title = { Text("听音选义", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
        backgroundColor = Color(0xFF8A8EFF),
        contentColor = Color.White
    )
}

@Composable
fun ChoiceButton2(text: String, onClick: () -> Unit, isCorrect: Boolean, isSelected: Boolean, modifier: Modifier = Modifier) {
    val backgroundColor = when {
        isSelected && isCorrect -> Color(0xFF8a8eff)
        isSelected && !isCorrect -> Color.Red
        else -> Color.White
    }

    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(backgroundColor = backgroundColor),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(vertical = 10.dp) // 按钮之间的间距
            .padding(horizontal = 1.dp) // 按钮左右间距
            .heightIn(min = 120.dp) // 增加按钮高度
    ) {
        Text(
            text = text,
            color = Color.Black,
            fontSize = 18.sp,
            textAlign = TextAlign.Center, // 使文本居中
            modifier = Modifier.padding(16.dp) // 增加文本的内边距
        )
    }
}

// 保存和获取当前单词索引的函数
fun saveListeningChoiceWordIndex(context: Context, index: Int) {
    val sharedPreferences = context.getSharedPreferences("listening_choice_prefs", Context.MODE_PRIVATE)
    sharedPreferences.edit().putInt("current_word_index", index).apply()
}

fun getListeningChoiceWordIndex(context: Context): Int {
    val sharedPreferences = context.getSharedPreferences("listening_choice_prefs", Context.MODE_PRIVATE)
    return sharedPreferences.getInt("current_word_index", 0)
}
