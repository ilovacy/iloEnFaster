package com.ilovacy.iloenfaster

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material.BottomNavigation
import androidx.compose.material.BottomNavigationItem
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.navOptions

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val settingsViewModel: SettingsViewModel = viewModel()
            val isDarkTheme by settingsViewModel.isDarkTheme.observeAsState(initial = false)
            val fontSize by settingsViewModel.fontSize.observeAsState(initial = 16f)

            MyAppTheme(darkTheme = isDarkTheme) {
                AppContent(navController = rememberNavController(), fontSize)
            }
        }
        createNotificationChannel()
        requestNotificationPermission()
        requestScheduleExactAlarmPermission()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Study Reminder"
            val descriptionText = "Channel for study reminders"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel("study_reminder_channel", name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 0)
        }
    }

    private fun requestScheduleExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(arrayOf(android.Manifest.permission.SCHEDULE_EXACT_ALARM), 0)
        }
    }
}

@Composable
fun AppContent(navController: NavController, fontSize: Float) {
    Scaffold(
        bottomBar = { AppBottomNavigation(navController) }
    ) { innerPadding ->
        NavHost(
            navController = navController as NavHostController,
            startDestination = "review",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("memorize") { MemorizeScreen(navController) }
            composable("review") { ReviewScreen(LocalContext.current) }
            composable("me") { MeScreen(navController) }
            composable("learning_settings") { LearningSettingsScreen(navController) }
            composable("word_check") { WordCheckScreen(navController) }
            composable("english_meaning") { EnglishMeaningScreen(navController) }
            composable("chinese_word") { ChineseWordScreen(navController) }
            composable("listening_choice") { ListeningChoiceScreen(navController) }
            composable("listening_word_choice") { ListeningWordChoiceScreen(navController) }
            composable("theme_settings") { ThemeSettingsScreen(navController) }
            composable("advanced_settings") { AdvancedSettingsScreen(navController) }
            composable("about_us") { AboutUsScreen(navController) }
            composable("user_feedback") { UserFeedbackScreen(navController) }
            composable("software_information") { MyApplicationInfoScreen(navController) }
            composable("web_view") { WebViewScreen(navController) }

        }
    }
}

@Composable
fun AppBottomNavigation(navController: NavController) {
    BottomNavigation(
        backgroundColor = Color.Transparent,
        elevation = 0.dp
    ) {
        val items = listOf("memorize", "review", "me")
        val currentRoute = navController.currentDestination?.route
        items.forEach { screen ->
            BottomNavigationItem(
                icon = {
                    Icon(
                        painter = painterResource(
                            id = when (screen) {
                                "memorize" -> R.drawable.ic_memorize
                                "review" -> R.drawable.ic_review
                                "me" -> R.drawable.ic_me
                                else -> R.drawable.ic_memorize
                            }
                        ),
                        contentDescription = screen
                    )
                },
                label = { Text(screen) },
                selected = currentRoute == screen,
                onClick = {
                    if (currentRoute != screen) {
                        navController.navigate(screen, navOptions {
                            anim {
                                enter = 0
                                exit = 0
                                popEnter = 0
                                popExit = 0
                            }
                        })
                    }
                },
                selectedContentColor = Color(0xFF8A8EFF),
                unselectedContentColor = Color.Gray
            )
        }
    }
}
