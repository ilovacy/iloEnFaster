package com.ilovacy.iloenfaster

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController

@Composable
fun ThemeSettingsScreen(navController: NavController, settingsViewModel: SettingsViewModel = viewModel()) {
    val isDarkTheme by settingsViewModel.isDarkTheme.observeAsState(initial = false)
    var showDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "主题设置",
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        color = Color.White
                    )
                },
                backgroundColor = Color(0xFF8A8EFF),
                contentColor = Color.White
            )
        },
        content = { innerPadding ->
            Box(modifier = Modifier.padding(innerPadding)) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = rememberRipple(bounded = true, color = Color.Gray),
                                onClick = { showDialog = true }
                            )
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(text = "切换到${if (isDarkTheme) "浅色" else "深色"}模式", fontSize = 16.sp, color = Color.Black)
                    }
                }

                if (showDialog) {
                    AlertDialog(
                        onDismissRequest = { showDialog = false },
                        title = { Text(text = "主题切换") },
                        text = { Text("切换主题将在重启后生效。") },
                        confirmButton = {
                            Button(
                                onClick = {
                                    settingsViewModel.toggleTheme()
                                    showDialog = false
                                },
                                shape = RoundedCornerShape(8.dp), // 设置圆角
                                colors = ButtonDefaults.buttonColors(backgroundColor = Color.White)
                            ) {
                                Text("确定", color = Color.Black)
                            }
                        },
                        dismissButton = {
                            Button(
                                onClick = { showDialog = false },
                                shape = RoundedCornerShape(8.dp), // 设置圆角
                                colors = ButtonDefaults.buttonColors(backgroundColor = Color.White)
                            ) {
                                Text("取消", color = Color.Black)
                            }
                        }
                    )
                }
            }
        }
    )
}
