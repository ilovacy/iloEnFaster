package com.ilovacy.iloenfaster

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.launch

@Composable
fun WordCheckScreen(navController: NavController) {
    val context = LocalContext.current
    val words = remember { loadWords(context) }
    var currentWord by remember { mutableStateOf<Word?>(null) }
    var showMeaning by remember { mutableStateOf(false) }
    var wordIndex by remember { mutableStateOf(getCurrentWordIndex(context, "word_check_index.json")) }
    val coroutineScope = rememberCoroutineScope()

    // 读取 JSON 文件中的单词计数信息
    var wordCountData by remember { mutableStateOf(loadWordCountData(context)) }

    LaunchedEffect(words, wordIndex) {
        if (words.isNotEmpty()) {
            currentWord = words[wordIndex]
            currentWord?.let {
                coroutineScope.launch {
                    downloadAndPlayAudio(context, it.单词)
                }
            }
        }
    }

    Scaffold(
        topBar = { WordCheckTopBar() },
        content = { innerPadding ->
            Box(modifier = Modifier.padding(innerPadding)) {
                WordCheckContent(
                    currentWord = currentWord,
                    showMeaning = showMeaning,
                    onCorrect = {
                        showMeaning = false
                        wordIndex = (wordIndex + 1) % words.size
                        saveCurrentWordIndex(context, wordIndex, "word_check_index.json")

                        // 更新单词计数信息
                        if (getCurrentDate() == wordCountData.todayDate) {
                            wordCountData.todayWords += 1
                        } else {
                            wordCountData.todayDate = getCurrentDate()
                            wordCountData.todayWords = 1
                        }
                        wordCountData.totalWords += 1
                        saveWordCountData(context, wordCountData)
                    },
                    onIncorrect = {
                        showMeaning = true
                    }
                )
            }
        }
    )
}

@Composable
fun WordCheckTopBar() {
    TopAppBar(
        title = { Text("单词自检", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
        backgroundColor = Color(0xFF8A8EFF),
        contentColor = Color.White
    )
}

@Composable
fun WordCheckContent(
    currentWord: Word?,
    showMeaning: Boolean,
    onCorrect: () -> Unit,
    onIncorrect: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFFF5F5F5), Color(0xFFE0E0E0))
                )
            )
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(modifier = Modifier.height(32.dp))

        currentWord?.let {
            Card(
                shape = RoundedCornerShape(16.dp),
                elevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp)
                    .height(250.dp)
            ) {
                Box(
                    modifier = Modifier
                        .background(Color.White, RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = it.单词,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp, // 调小字体
                            color = Color.Black,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        Text(
                            text = it.注音,
                            fontSize = 18.sp, // 调小字体
                            color = Color.Gray,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                        if (showMeaning) {
                            Text(
                                text = it.释义,
                                fontSize = 16.sp, // 调小字体
                                color = Color.Blue,
                                modifier = Modifier.padding(bottom = 16.dp)
                            )
                        }
                    }
                }
            }
        } ?: run {
            Text("加载单词中...", fontSize = 18.sp, color = Color.Gray)
        }

        Spacer(modifier = Modifier.height(32.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(
                onClick = onIncorrect,
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF8A8EFF)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .padding(horizontal = 8.dp)
            ) {
                Text(text = "不记得", color = Color.White, fontSize = 18.sp)
            }
            Button(
                onClick = onCorrect,
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF8A8EFF)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp) // 调整按钮高度防止释义显示不全
                    .padding(horizontal = 8.dp)
            ) {
                Text(text = "记得", color = Color.White, fontSize = 18.sp)
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}
