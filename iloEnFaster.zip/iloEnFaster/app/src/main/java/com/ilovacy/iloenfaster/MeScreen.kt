package com.ilovacy.iloenfaster

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberImagePainter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MeScreen(navController: NavController) {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE)
    val avatarPath = sharedPreferences.getString("avatarPath", null)
    var username by remember { mutableStateOf(sharedPreferences.getString("username", "ilovacy") ?: "ilovacy") }
    val coroutineScope = rememberCoroutineScope()

    var showMenu by remember { mutableStateOf(false) }
    var showAvatarDialog by remember { mutableStateOf(false) }
    var showEditUsernameDialog by remember { mutableStateOf(false) }
    var selectedAvatarUri by remember { mutableStateOf<Uri?>(null) }
    var editedUsername = remember { mutableStateOf(TextFieldValue(username)) }

    val avatarLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                try {
                    val savedUri = saveImageToInternalStorage(context, it)
                    if (savedUri != null) {
                        selectedAvatarUri = savedUri
                        savePreference(sharedPreferences, "avatarPath", savedUri.toString())
                    } else {
                        Log.e("MeScreen", "Failed to save image")
                    }
                } catch (e: Exception) {
                    Log.e("MeScreen", "Error saving image", e)
                }
            }
        }
    }

    // 读取 JSON 文件中的单词计数信息
    val wordCountData = loadWordCountData(context)

    Scaffold(
        topBar = { MeTopBar() },
        content = { innerPadding ->
            Box(modifier = Modifier.padding(innerPadding)) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFFF5F5F5))
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    UserInfoSection(
                        avatarPath = avatarPath,
                        onAvatarClick = { showMenu = true },
                        selectedAvatarUri = selectedAvatarUri,
                        username = username,
                        onEditUsernameClick = { showEditUsernameDialog = true }
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    MotivationalBoxes(todayCount = wordCountData.todayWords, totalCount = wordCountData.totalWords)
                    Spacer(modifier = Modifier.height(24.dp))
                    SettingsSection(navController)

                    if (showMenu) {
                        AvatarOptionsDialog(
                            onDismiss = { showMenu = false },
                            onViewAvatarClick = {
                                showAvatarDialog = true
                                showMenu = false
                            },
                            onChangeAvatarClick = {
                                avatarLauncher.launch("image/*")
                                showMenu = false
                            }
                        )
                    }

                    if (showAvatarDialog) {
                        AvatarDialog(
                            onDismiss = { showAvatarDialog = false },
                            selectedAvatarUri = selectedAvatarUri,
                            avatarPath = avatarPath
                        )
                    }

                    if (showEditUsernameDialog) {
                        EditUsernameDialog(
                            onDismiss = { showEditUsernameDialog = false },
                            editedUsername = editedUsername,
                            onSave = {
                                savePreference(sharedPreferences, "username", editedUsername.value.text)
                                username = editedUsername.value.text
                                showEditUsernameDialog = false
                            }
                        )
                    }
                }
            }
        }
    )
}

@Composable
fun MeTopBar() {
    TopAppBar(
        title = { Text("iloEnFaster", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
        backgroundColor = Color(0xFF8A8EFF),
        contentColor = Color.White,
        navigationIcon = {},
        actions = {
            Spacer(modifier = Modifier.width(56.dp))
        }
    )
}

@Composable
fun MotivationalBoxes(todayCount: Int, totalCount: Int) {
    Row(
        horizontalArrangement = Arrangement.SpaceEvenly,
        modifier = Modifier.fillMaxWidth()
    ) {
        NeumorphicBox(text = "今日已背单词: \n\t$todayCount 个", modifier = Modifier.weight(1f))
        Spacer(modifier = Modifier.width(16.dp))
        NeumorphicBox(text = "总计背单词: \n\t$totalCount 个", modifier = Modifier.weight(1f))
    }
}

@Composable
fun NeumorphicBox(text: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = text, fontSize = 16.sp, color = Color.Black, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun UserInfoSection(
    avatarPath: String?,
    onAvatarClick: () -> Unit,
    selectedAvatarUri: Uri?,
    username: String,
    onEditUsernameClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Color.LightGray)
                .clickable { onAvatarClick() }
        ) {
            when {
                selectedAvatarUri != null -> {
                    Image(
                        painter = rememberImagePainter(data = selectedAvatarUri),
                        contentDescription = "User Avatar",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                avatarPath != null -> {
                    val uri = Uri.parse(avatarPath)
                    Image(
                        painter = rememberImagePainter(data = uri),
                        contentDescription = "User Avatar",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
                else -> {
                    Image(
                        painter = painterResource(id = R.drawable.ic_default_avatar),
                        contentDescription = "Default Avatar",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }
        Text(
            text = username,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            modifier = Modifier
                .padding(vertical = 8.dp)
                .clickable { onEditUsernameClick() }
        )
        Text(
            text = "满堂花醉三千客，一件霜寒十四州",
            color = Color.Gray,
            fontSize = 16.sp
        )
    }
}

@Composable
fun AvatarOptionsDialog(onDismiss: () -> Unit, onViewAvatarClick: () -> Unit, onChangeAvatarClick: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("头像选项") },
        buttons = {
            Column {
                Text(
                    text = "查看头像",
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onViewAvatarClick() }
                        .padding(16.dp)
                )
                Divider()
                Text(
                    text = "更改头像",
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onChangeAvatarClick() }
                        .padding(16.dp)
                )
            }
        }
    )
}

@Composable
fun AvatarDialog(onDismiss: () -> Unit, selectedAvatarUri: Uri?, avatarPath: String?) {
    AlertDialog(
        onDismissRequest = onDismiss,
        buttons = {
            Box(modifier = Modifier.padding(16.dp)) {
                selectedAvatarUri?.let {
                    Image(
                        painter = rememberImagePainter(data = it),
                        contentDescription = "User Avatar",
                        modifier = Modifier
                            .size(200.dp)
                            .clip(CircleShape)
                            .background(Color.LightGray),
                        contentScale = ContentScale.Crop
                    )
                } ?: avatarPath?.let {
                    val uri = Uri.parse(it)
                    Image(
                        painter = rememberImagePainter(data = uri),
                        contentDescription = "User Avatar",
                        modifier = Modifier
                            .size(200.dp)
                            .clip(CircleShape)
                            .background(Color.LightGray),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }
    )
}

@Composable
fun EditUsernameDialog(onDismiss: () -> Unit, editedUsername: MutableState<TextFieldValue>, onSave: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("编辑用户名") },
        text = {
            OutlinedTextField(
                value = editedUsername.value,
                onValueChange = { editedUsername.value = it },
                label = { Text("用户名") }
            )
        },
        confirmButton = {
            Button(onClick = onSave, colors = ButtonDefaults.buttonColors(backgroundColor = Color.White)) {
                Text("保存", color = Color.Black)
            }
        },
        dismissButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(backgroundColor = Color.White)) {
                Text("取消", color = Color.Black)
            }
        }
    )
}

@Composable
fun SettingsSection(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        SettingsCategory(
            title = "主题和外观设置",
            onClick = { navController.navigate("theme_settings") }
        )
        SettingsCategory(
            title = "高级设置",
            onClick = { navController.navigate("advanced_settings") }
        )
        SettingsCategory(
            title = "关于我们",
            onClick = { navController.navigate("about_us") }
        )
        SettingsCategory(
            title = "软件信息",
            onClick = { navController.navigate("software_information") }
        )
        SettingsCategory(
            title = "用户反馈",
            onClick = { navController.navigate("user_feedback") }
        )
    }
}

@Composable
fun SettingsCategory(title: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White)
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 16.sp,
            color = Color.Black,
            modifier = Modifier.weight(1f)
        )
        Icon(
            painter = painterResource(id = R.drawable.ic_arrow_right),
            contentDescription = "Arrow Right",
            modifier = Modifier.size(24.dp)
        )
    }
}
