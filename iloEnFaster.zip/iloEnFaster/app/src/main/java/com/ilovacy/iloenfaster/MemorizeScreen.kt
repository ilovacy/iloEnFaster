package com.ilovacy.iloenfaster

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.rememberNavController

@Composable
fun MemorizeScreen(navController: NavController) {
    Scaffold(
        topBar = { MemorizeTopBar() },
        content = { innerPadding ->
            Box(modifier = Modifier.padding(innerPadding)) {
                MemorizeContent(navController)
            }
        }
    )
}

@Composable
fun MemorizeTopBar() {
    TopAppBar(
        title = { Text("iloEnFaster", modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center) },
        backgroundColor = Color(0xFF8A8EFF),
        contentColor = Color.White,
    )
}

@Composable
fun MemorizeContent(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        MemorizeButton("单词自检") {
            navController.navigate("word_check")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Spacer(modifier = Modifier.height(16.dp))

        MemorizeButton("英文选义") {
            navController.navigate("english_meaning")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Spacer(modifier = Modifier.height(16.dp))

        MemorizeButton("中文选词") {
            navController.navigate("chinese_word")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Spacer(modifier = Modifier.height(16.dp))

//        MemorizeButton("全拼默写") {
//        /* TODO: Implement this functionality */
//        }
//        Spacer(modifier = Modifier.height(16.dp))
        MemorizeButton("听音选词") {
            navController.navigate("listening_word_choice")
        }
        Spacer(modifier = Modifier.height(16.dp))
        Spacer(modifier = Modifier.height(16.dp))

        MemorizeButton("听音选义") {
            navController.navigate("listening_choice")
        }
    }
}

@Composable
fun MemorizeButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(backgroundColor = Color.White),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(80.dp)
    ) {
        Text(text = text, color = Color.Black, fontSize = 18.sp)
    }
}

@Preview(showBackground = true)
@Composable
fun MemorizeScreenPreview() {
    MemorizeScreen(navController = rememberNavController())
}
