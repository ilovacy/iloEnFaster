package com.ilovacy.iloenfaster

import android.content.Context
import android.content.SharedPreferences
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

fun saveCurrentWordIndex(context: Context, wordIndex: Int, fileName: String = "currentWordIndex.json") {
    val file = File(context.filesDir, fileName)
    file.writeText(wordIndex.toString())
}

fun getCurrentWordIndex(context: Context, fileName: String = "currentWordIndex.json"): Int {
    val file = File(context.filesDir, fileName)
    return if (file.exists()) {
        file.readText().toIntOrNull() ?: 0
    } else {
        0
    }
}

fun saveEnglishMeaningWordIndex(context: Context, wordIndex: Int) {
    val file = File(context.filesDir, "english_meaning_index.json")
    file.writeText(Gson().toJson(wordIndex))
}

fun getEnglishMeaningWordIndex(context: Context): Int {
    val file = File(context.filesDir, "english_meaning_index.json")
    if (file.exists()) {
        return Gson().fromJson(file.readText(), Int::class.java)
    }
    return 0
}

fun loadWords(context: Context): List<Word> {
    val jsonString: String = try {
        context.assets.open("words.json").bufferedReader().use { it.readText() }
    } catch (ioException: IOException) {
        ioException.printStackTrace()
        return emptyList()
    }

    val listType = object : TypeToken<List<Word>>() {}.type
    return Gson().fromJson(jsonString, listType)
}

suspend fun downloadWords(context: Context): List<Word>? {
    return withContext(Dispatchers.IO) {
        try {
            val url = URL("YOUR_WORDS_JSON_URL") // 替换成实际的单词数据URL
            val jsonString = url.readText()
            val listType = object : TypeToken<List<Word>>() {}.type
            val words: List<Word> = Gson().fromJson(jsonString, listType)

            // 保存到本地
            saveWordsToLocal(context, words)
            words
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}

fun saveWordsToLocal(context: Context, words: List<Word>) {
    val gson = Gson()
    val jsonString = gson.toJson(words)
    val file = File(context.filesDir, "words.json")
    file.writeText(jsonString)
}

suspend fun downloadAndPlayAudio(context: Context, word: String) {
    val audioFile = downloadAudio(context, word)
    if (audioFile != null) {
        playAudioFromFile(audioFile)
    }
}

suspend fun downloadAudio(context: Context, word: String): File? {
    return withContext(Dispatchers.IO) {
        try {
            val url = URL("https://dict.youdao.com/dictvoice?type=2&audio=$word")
            val connection = url.openConnection()
            connection.connect()
            val input = connection.getInputStream()
            val file = File(context.cacheDir, "$word.mp3")
            val output = FileOutputStream(file)
            val buffer = ByteArray(1024)
            var len: Int
            while (input.read(buffer).also { len = it } != -1) {
                output.write(buffer, 0, len)
            }
            output.close()
            input.close()
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}

fun getCurrentDate(): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    return sdf.format(Date())
}

fun playAudioFromFile(file: File) {
    val mediaPlayer = MediaPlayer()
    try {
        mediaPlayer.setDataSource(file.path)
        mediaPlayer.prepare()
        mediaPlayer.start()
    } catch (e: IOException) {
        e.printStackTrace()
    }
    mediaPlayer.setOnCompletionListener {
        it.release()
    }
}

fun savePreference(sharedPreferences: SharedPreferences, key: String, value: Any) {
    with(sharedPreferences.edit()) {
        when (value) {
            is Int -> putInt(key, value)
            is Boolean -> putBoolean(key, value)
            is String -> putString(key, value)
        }
        apply()
    }
}

suspend fun saveImageToInternalStorage(context: Context, uri: Uri): Uri? {
    return withContext(Dispatchers.IO) {
        try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(context.getExternalFilesDir(null), "IMG_$timeStamp.jpg")
            val outputStream = FileOutputStream(file)
            inputStream?.copyTo(outputStream)
            inputStream?.close()
            outputStream.close()

            Log.d("saveImageToInternalStorage", "Image saved successfully: ${file.absolutePath}")
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } catch (e: Exception) {
            Log.e("saveImageToInternalStorage", "Error saving image", e)
            null
        }
    }
}

fun saveWordCountData(context: Context, wordCountData: WordCountData) {
    val gson = Gson()
    val jsonString = gson.toJson(wordCountData)
    val file = File(context.filesDir, "word_count.json")
    file.writeText(jsonString)
}

fun loadWordCountData(context: Context): WordCountData {
    val file = File(context.filesDir, "word_count.json")
    if (!file.exists()) {
        return WordCountData(getCurrentDate(), 0, 0)
    }
    val jsonString = file.readText()
    val gson = Gson()
    return gson.fromJson(jsonString, object : TypeToken<WordCountData>() {}.type)
}
