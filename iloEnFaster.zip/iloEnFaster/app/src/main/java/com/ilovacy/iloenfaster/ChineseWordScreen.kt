package com.ilovacy.iloenfaster

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

@Composable
fun ChineseWordScreen(navController: NavController) {
    val context = LocalContext.current
    val words = remember { loadWords(context) }
    var currentWord by remember { mutableStateOf<Word?>(null) }
    var choices by remember { mutableStateOf(listOf<String>()) }
    var showAnswer by remember { mutableStateOf(false) }
    var isCorrect by remember { mutableStateOf(false) }
    var wordIndex by remember { mutableStateOf(getChineseWordIndex(context)) }
    val coroutineScope = rememberCoroutineScope()
    var selectedChoice by remember { mutableStateOf<String?>(null) }

    fun generateChoices(currentWord: Word?, words: List<Word>) {
        currentWord?.let {
            val correctAnswer = it.单词
            val wrongAnswers = words.shuffled().filter { it != currentWord }.take(3).map { it.单词 }
            choices = (wrongAnswers + correctAnswer).shuffled()
        }
    }

    LaunchedEffect(words) {
        if (words.isNotEmpty()) {
            currentWord = words[wordIndex]
            generateChoices(currentWord, words)
        }
    }

    Scaffold(
        topBar = { ChineseWordTopBar() },
        content = { innerPadding ->
            Box(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .background(Color(0xFFF5F5F5))
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Spacer(modifier = Modifier.height(32.dp))
                    currentWord?.let { word ->
                        Text(
                            text = word.释义,
//                            fontWeight = FontWeight.Bold,
                            fontSize = 19.sp,
                            textAlign = TextAlign.Center, // 使文本居中
                            color = Color.Black,
                            modifier = Modifier.padding(bottom = 20.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        choices.forEach { choice ->
                            ChoiceButton1(
                                text = choice,
                                onClick = {
                                    selectedChoice = choice
                                    showAnswer = true
                                    isCorrect = choice == word.单词
                                    if (isCorrect) {
                                        coroutineScope.launch {
                                            delay(300)
                                            showAnswer = false
                                            wordIndex = (wordIndex + 1) % words.size
                                            currentWord = words[wordIndex]
                                            saveChineseWordIndex(context, wordIndex)
                                            generateChoices(currentWord, words)
                                            selectedChoice = null
                                        }
                                    }
                                },
                                isCorrect = showAnswer && choice == word.单词,
                                isSelected = showAnswer && selectedChoice == choice,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 1.dp, vertical = 5.dp)
                                    .heightIn(min = 100.dp)
                            )
                        }
                    } ?: run {
                        Text("加载单词中...", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    }
                }
            }
        }
    )
}

@Composable
fun ChineseWordTopBar() {
    TopAppBar(
        title = { Text("中文选词", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
        backgroundColor = Color(0xFF8A8EFF),
        contentColor = Color.White
    )
}

@Composable
fun ChoiceButton1(text: String, onClick: () -> Unit, isCorrect: Boolean, isSelected: Boolean, modifier: Modifier = Modifier) {
    val backgroundColor = when {
        isSelected && isCorrect -> Color(0xFF8a8eff)
        isSelected && !isCorrect -> Color.Red
        else -> Color.White
    }


    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(backgroundColor = backgroundColor),
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(vertical = 10.dp) // 按钮之间的间距
            .padding(horizontal = 1.dp) // 按钮左右间距
            .heightIn(min = 100.dp) // 增加按钮高度
    ) {
        Text(
            text = text,
            color = Color.Black,
            fontSize = 18.sp,
            textAlign = TextAlign.Center, // 使文本居中
            modifier = Modifier.padding(16.dp) // 增加文本的内边距
        )
    }
}

// 保存和获取当前单词索引的函数
fun saveChineseWordIndex(context: Context, index: Int) {
    val sharedPreferences = context.getSharedPreferences("chinese_word_prefs", Context.MODE_PRIVATE)
    sharedPreferences.edit().putInt("current_word_index", index).apply()
}

fun getChineseWordIndex(context: Context): Int {
    val sharedPreferences = context.getSharedPreferences("chinese_word_prefs", Context.MODE_PRIVATE)
    return sharedPreferences.getInt("current_word_index", 0)
}
