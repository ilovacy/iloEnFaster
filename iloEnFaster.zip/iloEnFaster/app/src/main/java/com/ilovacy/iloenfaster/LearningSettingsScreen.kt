package com.ilovacy.iloenfaster

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.widget.TimePicker
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import java.util.*

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun LearningSettingsScreen(navController: NavController) {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("学习设置") },
                navigationIcon = {
                    IconButton(onClick = { navController.navigateUp() }) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_back),
                            contentDescription = "Back"
                        )
                    }
                },
                backgroundColor = Color(0xFF8A8EFF)
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = "学习设置",
                style = MaterialTheme.typography.h6,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            StudyReminderSetting(sharedPreferences)
        }
    }
}

@Composable
fun StudyReminderSetting(sharedPreferences: SharedPreferences) {
    var reminderEnabled by remember { mutableStateOf(sharedPreferences.getBoolean("reminderEnabled", false)) }
    var reminderTime by remember { mutableStateOf(sharedPreferences.getString("reminderTime", "08:00") ?: "08:00") }
    val context = LocalContext.current

    val timePickerDialog = remember { mutableStateOf<TimePickerDialog?>(null) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White, shape = RoundedCornerShape(8.dp))
            .padding(16.dp)
    ) {
        Text(
            text = "学习提醒",
            style = MaterialTheme.typography.h6,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = reminderEnabled,
                onCheckedChange = {
                    reminderEnabled = it
                    savePreference1(sharedPreferences, "reminderEnabled", reminderEnabled)
                    if (reminderEnabled) {
                        scheduleReminder(context = context, time = reminderTime)
                    } else {
                        cancelReminder(context = context)
                    }
                }
            )
            Text(
                text = "启用提醒",
                fontSize = 16.sp
            )
        }
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "提醒时间：",
                fontSize = 16.sp,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = {
                timePickerDialog.value = TimePickerDialog(
                    context,
                    { _: TimePicker, hourOfDay: Int, minute: Int ->
                        reminderTime = String.format("%02d:%02d", hourOfDay, minute)
                        savePreference1(sharedPreferences, "reminderTime", reminderTime)
                        if (reminderEnabled) {
                            scheduleReminder(context = context, time = reminderTime)
                        }
                    },
                    reminderTime.split(":")[0].toInt(),
                    reminderTime.split(":")[1].toInt(),
                    true
                )
                timePickerDialog.value?.show()
            }) {
                Text(text = reminderTime)
            }
        }
    }
}

fun savePreference1(sharedPreferences: SharedPreferences, key: String, value: Any) {
    val editor = sharedPreferences.edit()
    when (value) {
        is Int -> editor.putInt(key, value)
        is String -> editor.putString(key, value)
        is Boolean -> editor.putBoolean(key, value)
        else -> throw IllegalArgumentException("Unsupported preference type")
    }
    editor.apply()
}

@SuppressLint("ScheduleExactAlarm")
fun scheduleReminder(context: Context, time: String) {
    if (time.isNotBlank()) {
        val timeParts = time.split(":")
        if (timeParts.size == 2) {
            val hour = timeParts[0].toIntOrNull()
            val minute = timeParts[1].toIntOrNull()
            if (hour != null && minute != null) {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val intent = Intent(context, ReminderReceiver::class.java)
                val pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

                val calendar = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (context.checkSelfPermission(android.Manifest.permission.SCHEDULE_EXACT_ALARM) == PackageManager.PERMISSION_GRANTED) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
                    }
                } else {
                    alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
                }
            }
        }
    }
}

fun cancelReminder(context: Context) {
    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, ReminderReceiver::class.java)
    val pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    alarmManager.cancel(pendingIntent)
}
